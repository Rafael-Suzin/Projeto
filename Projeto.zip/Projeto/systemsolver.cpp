#include "systemsolver.h"

SystemSolver::SystemSolver()
{

}
