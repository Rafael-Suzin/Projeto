//#ifndef SYSTEMSOLVER_H
//#define SYSTEMSOLVER_H

//#include <C:\Users\Aluno\Desktop\prova1_2\Projeto\Eigen\Dense>

//#include <QCoreApplication>

//#include <iostream>
//#include <C:\Users\Aluno\Desktop\prova1_2\Projeto\Eigen\Dense>
//#include <vector>
//#include <string>

//#include <QString>

//class SystemSolver {
//public:
//    SystemSolver(MatrixXd cof,VectorXd igual) {
//        this->cof = cof;
//        this->igual = igual;
//        n_var = cof.cols();
//        n_eq = cof.rows();
//        var.resize(n_var, " ");
//        //        char a = 'a'; //'a'=97
//        for (int i = 0; i < n_var; i++) {
//            var[i] = string(1, i+'a');
//        }
//        retorno=system_analize();
//    }

//    void solve() {
//        solution = cof.colPivHouseholderQr().solve(igual);
//    }

//    VectorXd getSolution() {
//        return solution;
//    }
//    double det(){
//        return cof.determinant();
//    }
//    int returno(){
//        return retorno;
//    }
//    int get_n_var(){
//        return retorno;
//    }
//    int get_n_eq(){
//        return n_eq;
//    }
//private:
//    MatrixXd cof; //matriz nxm
//    VectorXd igual;
//    VectorXd solution;

//    int n_var;
//    int n_eq;
//    QString var;
//    int retorno;
//    int system_analize() {
//        //        cout << "Determinante: " << cof.determinant() << "\n";

//        if (n_var == n_eq) {
//            if (cof.determinant() != 0) {
//                solve();
//                return 0;
//            } else {
//                //                cout << "Solução geral: ";
//                // Implementar uma lógica para lidar com sistemas indeterminados
//                return 2;
//            }
//        } else if (n_var > 1 && n_eq == 1) {
//            return 1;
//        } else {

//            // Implementar lógica para simplificar o
//            return -1;
//        }
//    }
//};

//#endif // SYSTEMSOLVER_H
